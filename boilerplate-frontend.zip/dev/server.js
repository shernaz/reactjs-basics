var express = require('express');

// Path to our public directory
var pub = __dirname;

// setup middleware
var main = express();
main.use(express.static(pub));

// Optional since express defaults to CWD/views

main.set('views', pub + '/html');
main.locals.basedir = main.get('views');
main.locals.pretty = true;

main.set('view engine', 'pug');

main.get('/', function (req, res) {
	res.render('index');
});

main.get('/*', function (req, res) {
	res.render(req.params[0], { production: false });
});

if (!module.parent) {
	main.listen(3000);
	console.log('Express started: http://localhost:3000');
}