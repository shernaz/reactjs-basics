---README - USAGE---

QUICK START (after setup)
-------------------------------
1. start your server by clicking the server.bat, or type "npm run server" into the command line (inside the /dev path). Your project is available on http://localhost:3000
2. execute "npm run watch" in your command line / or open the watch.bat
3. The environment is up and running! Let's start working :-)


IT'S ALL NODEJS
-------------------------------
We use Pug (previously named Jade) for writing html templates, Gulp as our task runner and Express as server to view our templates. 
These are all driven by the NodeJS environment.


SETUP
-------------------------------
- Install NodeJS (^6.1.0), if not installed yet.
- Install packages by typing "npm install" in your command line (or run install-packages.bat inside the dev folder)


HOW TO USE
-------------------------------

	Folder structure
	---------------------------
	Our folder structure will look like this:
	- dev
		- assets
		- html
	- images *
	- assets *
	- dist *
	- public **
		- assets
		- images

	We only work inside the dev folder. The folders with the * suffix are generated folders by Gulp taks. Those folders should not be edited by hand, because it will be overwritten when the build command is executed e.g.
	The single * folders are meant for our back-end developers. The dist folder includes all the html output, the assets folder includes only the needed static files (so, no workfiles like sass)
	The double ** folders are meant for front-end publish purposes e.g. testing

	Pug
	---------------------------
	Pug is a language for writing html templates. How to use Pug? http://jade-lang.com/reference/


	Command line
	---------------------------
	It's up to you how to run the commands you need. 
	For Gulp Visual Studio has built-in features and many text editors like Sublime offer a plugin to run Gulp tasks within the editor (note: you need to install Gulp globally if you want to take advantage of this).

		Server
		-----------------------
		In the /dev folder we have a file named server.bat. When you open it, it will directly start the server on localhost:3000. 
		You should keep this panel open while using the server, closing it will terminate the command and close the server.
		You can also type "npm run server" in your command line to start the server.

		Gulp 
		------------------------
		With gulp we run tasks like compiling the Sass, minifying files and building pure html templates from our Pug files.
		The available tasks are present in the gulpfile.js and several are mapped in the package.json to easily run tasks via the command line.

		The commands available in the package.json are:
		npm run server	 (runs the Express server)
		npm run watch    (watches all scss, js and images files in the dev folder and runs a specific task when the file changes)
		npm run build    (runs all tasks for a complete build of our files, compiled/copied/written to the assets and dist folder).
		npm run publish  (will build and publish all files. note: publish path must be set into gulpfile)