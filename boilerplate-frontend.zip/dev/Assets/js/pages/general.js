if(cdb === undefined) {
	var cdb = this;
}

(function($, pages, components, lib) {
	'use strict';

	pages.General = function() {

		function init() {

			if (typeof lib.ResponsiveHandler === 'object') {
				var responsiveHandler = lib.ResponsiveHandler;
				responsiveHandler.init();
			}

			$('.cmp-field-select.single select').select2({
				theme: 'classic',
			});
		
			$('.cmp-field-select.multiple select').select2({
				theme: 'classic',
				multiple: true
			});
		}

		return {
			init: init
		};
	}();

})(jQuery, cdb.pages = (cdb.pages === undefined) ? {} : cdb.pages, cdb.components = (cdb.components === undefined) ? {} : cdb.components, cdb.lib = (cdb.lib === undefined) ? {} : cdb.lib);