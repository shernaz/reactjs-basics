if(cdb === undefined) {
	var cdb = this;
}

(function($, pages, components) {
	'use strict';

	pages.Homepage = function() {

		function init() {
			
		}

		return {
			init: init
		};
	}();

})(jQuery, cdb.pages = (cdb.pages === undefined) ? {} : cdb.pages, cdb.components = (cdb.components === undefined) ? {} : cdb.components);