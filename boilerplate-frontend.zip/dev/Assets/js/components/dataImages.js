if(cdb === undefined) {
	var cdb = this;
}

(function($, components, responsiveHandler) {
'use strict';

	 components.DataImages = function() {

	 	var backgroundPattern,
	 		imgPattern;

	 	function init() {

			$('[data-background]').each(function () {
				var image = $(this).data('background');
				$(this).css('background-image', 'url("' + image + '")');
			});

			if(responsiveHandler.breakpointActive('phone-portrait, phone-landscape')) {
				imgPattern = 'img-phone';
				backgroundPattern = 'background-phone';
			}
			else if(responsiveHandler.breakpointActive('tablet-portrait, tablet-landscape')) {
				imgPattern = 'img-tablet';
				backgroundPattern = 'background-tablet';
			}
			else if(responsiveHandler.breakpointActive('desktop')) {
				imgPattern = 'img-desktop';
				backgroundPattern = 'background-desktop';
			}


			$('[data-'+imgPattern+']').each(function () {
				var image = $(this).data(imgPattern);
				$(this).attr('src', image);
			});
			
			$('[data-'+backgroundPattern+']').each(function () {
				var image = $(this).data(backgroundPattern);
				$(this).css('background-image', 'url("' + image + '")');
			});

		}

		return {
			init: init
		};

	}();

})(jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components, cdb.lib.ResponsiveHandler);