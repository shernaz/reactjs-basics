if(cdb === undefined) {
	var cdb = this;
}

(function($, components) {
'use strict';

	 components.DataVideo = function() {

	 	function init() {
			$('[data-video]').on('click', openVideoPopup);
		}

		function openVideoPopup(e) {
			var url = $(e.target).data('video');
			var $videoPopup = $('.overlay.video');

			setTimeout(function () {
				$videoPopup.find('iframe').attr('src', url);
				$('.video-open').on('click', closeVideoPopup.bind($videoPopup.find('.close')));
			}, 500);
			
			$videoPopup.addClass('active');
			$('body').addClass('overlay-open');

			$videoPopup.find('.close').on('click', closeVideoPopup);

			var $scrollVideo = $('.overlay');
			$scrollVideo.css('margin-top', $(window).scrollTop());
		}

		function closeVideoPopup(e) {
			$(e.target).off('click');
			$('.overlay-open').off('click');
			var $videoPopup = $(e.target).closest('.overlay');
			setTimeout(function () {
				$videoPopup.find('iframe').attr('src', '');
			}, 500);
			$videoPopup.removeClass('active');
			$('body').removeClass('overlay-open');
		}

		return {
			init: init
		};
	}();

})(jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components);