if(cdb === undefined) {
	var cdb = this;
}

(function($, components) {
'use strict';

	components.ToggleData = function() {

		function init() {
			$('[data-toggle]').on('click', toggleDataElement);
		}

		function toggleDataElement(e){
			var elements = $(this).data('toggle');
			var arr = elements.split(',');
			var $el = $(this);
			
			$.each(arr, function(index, value) {
				var $toggleElement = $el.closest(value);
				$toggleElement.toggleClass('active');
			});
		}

		return {
			init: init
		};
	}();
	
})(jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components);