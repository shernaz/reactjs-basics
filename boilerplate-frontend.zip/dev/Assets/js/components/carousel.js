if(cdb === undefined) {
	var cdb = this;
}

/*
	PUG example:

		section.s-carousel
			.carousel-items
				.carousel-item(data-img-phone-src="http://placehold.it/768x340/e43637/ffffff" data-img-tablet-src="http://placehold.it/1024x500/e43637/ffffff" data-img-desktop-src="http://placehold.it/1920x500/e43637/ffffff" data-title="Lorem ipsum")
					.container
						.content.
							Lorem ipsum dolor sit amet

				.carousel-item(data-img-phone-src="http://placehold.it/768x300/000000/e43637" data-img-tablet-src="http://placehold.it/1024x500/000000/e43637" data-img-desktop-src="http://placehold.it/1920x500/000000/e43637" data-title="Sit amet")
					.container
						.content.
							Sit amet lorem ipsum dolor

	_carousel.scss is styled for this pug / js

*/

(function($, components, touch, responsiveHandler) {
	'use strict';

	 components.Carousel = function Carousel() {

		/* default carousel settings */
			var settings = {
			carousel: '.s-carousel',
			carouselName: 'carousel',
			automaticRotation: true,
			enableTransition: true,
			transitionType: 'Parallax',
			displayMode: 'cover',
			initialIndex: 0,
			animationDuration: 1000,
			rotationTimeout: 9000,
			autoResumeTimeout: 7000,
			navigationDisabled: false,
			preloadImagesEnabled: true,
			preloadImageDelay: 0,
			showIndicators: true
		};

		/* function scoped variables */
		var $carousel,
			$navigation,
			$leftHoverBlock,
			$rightHoverBlock,
			$indicators,
			$previousButton,
			$nextButton,
			$items,
			$targetItem,
			$currentItem,
			images = [],
			currentIndex,
			targetIndex,
			maxIndex,
			rotationInterval,
			navTimeout,
			direction;


		function init(carouselSettings) {
			$.extend(settings, carouselSettings);

			// get carousel
			$carousel = $(settings.carousel);

			// init $items
			$items = $carousel.find('.'+settings.carouselName + '-item');

			if($items.length === 0) {
				return;
			}
			else if ($items.length === 1) {
				settings.showIndicators = false;
			}

			//click action on each item
			$items.on('click', navigateTo);

			maxIndex = $items.length - 1;

			// create carousel navigation
			if ($items.length > 1 && $('body.pageeditor').length === 0) {
				createNavigation();
				if (settings.showIndicators) {
					createIndicators();
				}
				autoRotate();
			}

			showInitialItem();
		}

		function navigateTo(e) {
			var url = $(e.currentTarget).data('url');
			if (url) {
				window.location.href = url;
			}
		}

		function showInitialItem() {

			// get target item
			defineTargetItem(settings.initialIndex);
			$targetItem.css('z-index', '2');

			// load quality image
			loadImage(settings.initialIndex);

			setTargetAsCurrent();

			if (settings.preloadImagesEnabled) {
				setTimeout(function () {
					preloadImages();
				}, settings.preloadImageDelay);
			}

			activateIndicator(settings.initialIndex);
		}

		function showNextItemByUserAction() {
			if (!settings.navigationDisabled) {
				showNextItem();
				stopAutoRotate();
			}
		}

		function showPreviousItemByUserAction() {
			if (!settings.navigationDisabled) {
				showPreviousItem();
				stopAutoRotate();
			}
		}

		function showItemByUserAction(index, e) {
			if (!settings.navigationDisabled && currentIndex !== index) {
				showItem(index);
				stopAutoRotate();
			}
		}

		function showNextItem() {
			var index = currentIndex + 1;
			if (currentIndex == maxIndex) {
				index = 0;
			}
			direction = 'next';
			showItem(index);
		}

		function showPreviousItem() {
			var index = currentIndex - 1;
			if (currentIndex === 0) {
				index = maxIndex;
			}
			direction = 'prev';
			showItem(index);
		}

		function preloadImages() {
			$items.each(function (i) {
				if (i != settings.initialIndex) {
					loadImage(i);
				}
			});
		}

		function showItem(index) {
			disableInteraction();
			defineTargetItem(index);

			if (!settings.navigationDisabled) {
				stopAutoRotate();
			}

			if ($targetItem && $currentItem && $targetItem.get(0) === $currentItem.get(0)) {
				return;
			}

			transition();
			setNewSlide();
			activateIndicator(index);
		}

		function defineTargetItem(attr) {
			// define target item based on index
			if (typeof attr == 'number') {
				$targetItem = $items.eq(attr);
				targetIndex = attr;
			}
				// define target item based on img-src
			else {
				for (var i = 0; i < $items.length; i++) {
					$item = $($items[i]);
					var imgSrc = getImageSrc($item);

					if (imageSrc == attr) {
						$targetItem = $item;
						targetIndex = i;
						break;
					}
				}
			}
		}

		function getImageSrc($item) {
			var src;

			if(responsiveHandler.breakpointActive('phone-portrait, phone-landscape')) {
				src = $item.data('img-phone-src');
			}
			else if(responsiveHandler.breakpointActive('tablet-portrait, tablet-landscape')) {
				src = $item.data('img-tablet-src');
			}
			else {
				src = $item.data('img-desktop-src');
			}

			return src;
		}

		function activateIndicator(index) {
			if (settings.showIndicators && $indicators) {
				var $indicatorItems = $indicators.find('.indicator');
				$indicatorItems.removeClass('active');
				$indicatorItems.eq(index).addClass('active');
			}
		}

		function setTargetAsCurrent() {
			var $previousItem = $currentItem;
			$currentItem = $targetItem;
			currentIndex = targetIndex;
			$currentItem.css('z-index', '2').attr('aria-selected', true);
			$currentItem.addClass('active');
			if ($previousItem !== null && $previousItem !== undefined) {
				$previousItem.css('z-index', '0').attr('aria-selected', false);
				$previousItem.removeClass('active');
			}
			$targetItem = null;
			targetIndex = null;
		}

		function autoRotate() {
			if (settings.automaticRotation === true) {
				rotationInterval = setInterval(function () {
					showNextItem();
				}, settings.rotationTimeout);
			}
		}

		function stopAutoRotate() {
			clearInterval(rotationInterval);
			setTimeout(function () {
				clearInterval(rotationInterval);
				autoRotate();
			}, settings.autoResumeTimeout);
		}

		function createNavigation() {

			// create navigation button wrapper
			$navigation = $('<div class="'+settings.carouselName+'-nav"></div>');

			$leftHoverBlock = $('<div class="hover-block-left"></div>');
			$leftHoverBlock.on('mouseenter', function () {
				$previousButton.addClass('visible');
				clearTimeout(navTimeout);
			});
			$leftHoverBlock.on('mouseleave', function () {
				$previousButton.removeClass('visible');
			});
			$leftHoverBlock.click(function (e) {
				e.preventDefault();
				showPreviousItemByUserAction();
			});

			$rightHoverBlock = $('<div class="hover-block-right"></div>');
			$rightHoverBlock.on('mouseenter', function () {
				$nextButton.addClass('visible');
				clearTimeout(navTimeout);
			});
			$rightHoverBlock.on('mouseleave', function (e) {
				$nextButton.removeClass('visible');
			});
			$rightHoverBlock.click(function (e) {
				e.preventDefault();
				showNextItemByUserAction();
			});

			// create previous button
			$previousButton = $('<span class="nav-prev visible"></span>');

			// create next button
			$nextButton = $('<span class="nav-next visible"></span>');

			touch.track($leftHoverBlock);
			$leftHoverBlock.addGestureListener('tap', showPreviousItemByUserAction);
			$leftHoverBlock.addGestureListener('swipeRight', showPreviousItemByUserAction);

			touch.track($rightHoverBlock);
			$rightHoverBlock.addGestureListener('tap', showNextItemByUserAction);
			$rightHoverBlock.addGestureListener('swipeLeft', showNextItemByUserAction);

			var $wrapper = $('.carousel-items');
			touch.track($wrapper);
			$wrapper.addGestureListener('tap', showNextItemByUserAction);
			$wrapper.addGestureListener('swipeRight', showPreviousItemByUserAction);
			$wrapper.addGestureListener('swipeLeft', showNextItemByUserAction);


			$wrapper.addGestureListener('swipeUp', function () {
				var position = carousel.position().top + carousel.height();
				$(window).scrollTop(position);
			});

			// append navigation buttons
			$navigation.append($previousButton);
			$navigation.append($nextButton);
			$carousel.append($navigation);
			$carousel.append($leftHoverBlock);
			$carousel.append($rightHoverBlock);

			navTimeout = setTimeout(hideNavButtons, 2000);
		}

		function hideNavButtons() {
			$previousButton.removeClass('visible');
			$nextButton.removeClass('visible');
		}

		function createIndicators() {
			$indicators = $('<div class="carousel-indicators"></div>');
			for (var i = 0; i < $items.length; i++) {
				var title = $items.eq(i).data('title');
				var $indicator = $('<div class="indicator" data-title="'+title+'"></div>');
				$indicator.on('click', showItemByUserAction.bind($indicator, i));
				$indicators.append($indicator);
			}
			$carousel.append($indicators);
		}

		function loadImage(index) {
			var $item = $($items[index]);
			if ($item.hasClass('bg-loaded') || $item.hasClass('img-loaded')) {
				return;
			}

			var targetImageHeight = $item.parent().height(),
				targetImageWidth = $item.parent().width(),
				hasImg = $item.hasClass('img'),
				src = getImageSrc($item),
				baseUrl = getBaseUrl(src);

			$item.css('background-image', 'url(' + baseUrl + ')');
			if (hasImg) {
				$item.css('background-size', 'contain');
			}
			$item.addClass('bg-loaded');

			if ($item.hasClass('video')) { //add click action if video is available
				$item.on('click', openVideo);
			}
		}

		function transition() {
			// set target item behind current item
			$targetItem.css('z-index', '3');
			var amountPixelsToSlide = 100; //percent

			if(direction === 'prev' || targetIndex - currentIndex === -1 || targetIndex === maxIndex && currentIndex === 0) {
				amountPixelsToSlide = -amountPixelsToSlide;
			}

			// set other $items
			$items.each(function () {
				var $loopItem = $(this);
				if ($loopItem.get(0) !== $currentItem.get(0) && $loopItem.get(0) !== $targetItem.get(0)) {
					$loopItem.css('z-index', '0');
				}
			});

			// start position
			$targetItem.css('transform', 'translateX('+ amountPixelsToSlide + '%)');

			setTimeout(function () {
				enableTransitions($targetItem, settings.animationDuration, 'transform');

				switch (settings.transitionType) {
					case "Slide":
						enableTransitions($currentItem, settings.animationDuration, 'transform');
						break;
					case "Parallax":
						enableTransitions($currentItem, settings.animationDuration * 1.4, 'transform');
						break;
				}

				$currentItem.css('transform', 'translateX('+ -amountPixelsToSlide + '%)');
				$targetItem.css('transform', 'translateX(0)');

			}, 100);
		}

		function setNewSlide() {

			setTimeout(function () {
				disableTransitions($currentItem);
				$targetItem.css('transform', 'translateX(0)');
				setTargetAsCurrent();
				preloadImages();
				direction = null;
				enableInteraction();
			}, (settings.animationDuration) + 100);
		}

		function openVideo(e) {
			var $iframe = $(e.currentTarget).find('iframe').clone(),
				src = $iframe.attr('src') + '?autoplay=1',
				$videoPopup = $(document.createElement('div')).addClass('cmp-popup video'),
				$close = $(document.createElement('span')).addClass('close');

			$iframe.attr('src', src);
			$videoPopup.append($close);
			$videoPopup.append($iframe);

			$close.on('click', function () {
				$videoPopup.remove();
			});

			$('body').append($videoPopup);
		}

		function disableInteraction() {
			$carousel.addClass('disabled');
			settings.navigationDisabled = true;
		}

		function enableInteraction() {
			$carousel.removeClass('disabled');
			settings.navigationDisabled = false;
		}

		function getBaseUrl(url) {
			if (url.indexOf('?') >= 0) {
				return url.substr(0, url.indexOf('?'));
			}
			else {
				return url;
			}
		}

		function enableTransitions($element, duration, type) {
			if($element === null) return;
			if (!type) {
				type = 'all';
			}
			duration = duration + 'ms';
			$element.css('transition', type + ' ' + duration + ' ease');
		}

		function disableTransitions($element) {
			$element.css('transition', 'none');
		}

		return {
			init: init
		};
	};
})(
jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components, cdb.lib.Touch, cdb.lib.ResponsiveHandler);