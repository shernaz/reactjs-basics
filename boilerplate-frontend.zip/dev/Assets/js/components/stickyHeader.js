if(cdb === undefined) {
	var cdb = this;
}

(function($, components) {
'use strict';

	 components.StickyHeader = function() {

	 	function init() {
	 		$( window ).scroll(function() {
				self.scrollPos = $(this).scrollTop();

	 			$('[data-sticky]').each(function (attr) {
					self.elementPos = $(this).position().top + 10;
					var element = $(this).data('sticky');
					var $stickyEl = $(this).closest(element);

					if ($stickyEl.length === 0) {
						$stickyEl = $(this).find(element);
					}

					if (self.scrollPos > self.elementPos) {
						$stickyEl.addClass('sticky');
					}

					else {
						$stickyEl.removeClass('sticky');
					}

					if (self.scrollPos === 0) {
						$stickyEl.removeClass('sticky');
					}
				});
	 		});
		}

		return {
			init: init
		};

	}();

})(jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components);