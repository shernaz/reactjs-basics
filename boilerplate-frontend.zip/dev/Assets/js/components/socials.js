if(cdb === undefined) {
	var cdb = this;
}

(function($, components) {
'use strict';

	components.Socials = function() {

		function init() {
			$('.cmp-social [data-url]').on('click', function(event) {
				handleSocials(event);
			});
		}

		function handleSocials(e) {
			var src = getLink(e);
			window.open(src, 'popup', 'width=626 , height=436');
		}

		function getLink(e) {
			e.preventDefault();
			var src = $(e.target).find('a').attr('href') || $(e.target).closest('a').attr('href') || $(e.target).data('url') || $(e.target).closest('[data-url]').data('url');
			return src;
		}

		return {
			init: init
		};
	}();

})(jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components);