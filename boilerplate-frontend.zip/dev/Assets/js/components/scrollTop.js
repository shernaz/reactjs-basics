if(cdb === undefined) {
	var cdb = this;
}

(function($, components) {
'use strict';

	 components.ScrollTop = function() {

	 	function init() {

			$(window).scroll(function() {
				var y = $(this).scrollTop();
				if (y > 800) {
					$('.to-top').fadeIn();
				} else {
					$('.to-top').fadeOut();
				}
			});

			$('.to-top').on('click touchstart', function () {
				$('body, html').animate({
					scrollTop: 0
				}, 700);
			});
		}

		return {
			init: init
		};

	}();

})(jQuery, cdb.components = (cdb.components === undefined) ? {} : cdb.components);