(function($, project) {
	'use strict';

	if (!('pages' in project)) {
    	project.pages = {};
	}

	var general = project.pages.General;
	var page = $('main').data('page');
	page = project.pages[page];

	general.init();
	
	if(page === undefined) return;
	page.init();

})(jQuery, cdb = (cdb === undefined) ? window : cdb);