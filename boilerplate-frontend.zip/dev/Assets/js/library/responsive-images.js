"use strict";

function module_responsive_images() {

	var images = null;

	function init(){
		images = $('img.responsive-image');
	}

	function update(topic, data){
		$(images).each(function () {

			// get parent width, create url parameter
			var width_parameter = '';
			var parent_width = $(this).parent().width();
			if (parent_width > 0) {
				width_parameter = '&width=' + parent_width;
			}

			// let imageGen return image
			var src = $(this).data("location") + width_parameter;
			$(this).prop('src', src);

		});
	}

	return {
		init : init,
		update : update
	};
}