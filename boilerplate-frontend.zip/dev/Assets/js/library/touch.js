/*
	
	** DESCRIPTION ** 
	Touch framework
	
	
	** USAGE **
	// create touch object
	var touch = new Touch();
	
	// get element
	var box = $('#box');
	
	// track touches on element
	touch.track(box);
	
	// act on gestures made by user
	box.addGestureListener(GESTURE, CALLBACK);
	box.addGestureListener('tap', function(){ console.log('tapped');} );
	box.addGestureListener('pinch', function(){ console.log('pinching'); });
	
	** GESTURES **
	tap, pinch, pinchIn, pinchOut, drag, swipe, swipeUp, swipeRight, swipeLeft, swipeDown
	
	
	** RETURNS **
	touch object or array of touch objects.
	Touch object is default touch object extended with some properties.
	- Gesture drag will return a array of historic positions include last position.
	
	None moving gestures
	pageXStart -> start horizontal position
	pageYStart -> start vertical position
	
	Moving gestures
	pageXStart -> start horizontal position
	pageYStart -> start vertical position
	trackX -> array of historical horizontal positions
	trackY -> array of historical vertical positions
	pageXLatest -> latest horizontal position
	pageYLatest -> latest vertical position
	pageXDifference -> horizontal distance covered relative to start of touch
	pageYDifference -> vertical distance covered relative to start of touch
	pageDifference -> distance covered relative to start of touch
	velocity -> calculated velocity of finger
	
	
*/

if(cdb === undefined) {
	var cdb = this;
}

(function($, lib) {
	'use strict';

	lib.Touch = function() {

		var start = 0;
		var end = 0;
		var duration = 0;
		var touches = [];
		var positionHistory = [];
		var DOMelement;
		var isTapping;


		// define actions which de user is possible trying to do
		var userActions = {
			tapping: true, // tapping is always a possibility
			dragging: false,
			swiping: false,
			pinching: false
		};

		// track touch events on element
		function track(element) {
			element.touch = {};
			trackTouchStart(element);
			trackTouchMove(element);
			trackTouchEnd(element);
			trackTouchEnter(element);
			trackTouchLeave(element);
			trackTouchCancel(element);
			element.addGestureListener = addGestureListener;
		}

		function clearTrackers() {
			start = end = duration = 0;
			positionHistory = [];
			userActions.tapping = true;
			userActions.dragging = false;
			userActions.swiping = false;
			userActions.pinching = false;
		}

		function calculateDuration() {
			duration = end - start;
		}


		function trackTouchStart(element) {
			DOMelement = element[0];
			DOMelement.addEventListener('touchstart', function (e) {
				// default user action is tapping
				isTapping = true;

				// new event happening. lets clear all vars
				clearTrackers();

				// setting event start time
				var d = new Date();
				start = d.getTime();

				// set start touches
				touches = e.targetTouches;
				for (var i = 0; i < touches.length; i++) {
					touches[i].pageXStart = touches[i].pageX;
					touches[i].pageYStart = touches[i].pageY;
				}

				e.preventDefault();
				e.stopPropagation();

			}, false);
		}


		function trackTouchMove(element) {
			DOMelement = element[0];
			DOMelement.addEventListener('touchmove', function (e) {

				// calculate event duration
				var d = new Date();
				end = d.getTime();
				calculateDuration();

				var touch;

				// Track touch offset and velocity
				for (var i = 0; i < touches.length; i++) {
					touch = touches[i];

					// keep track on touch X movement
					if (typeof touch.trackX == "undefined") {
						touch.trackX = [e.targetTouches[i].pageX];
					}
					else {
						touch.trackX.push(e.targetTouches[i].pageX);
					}

					// keep track on touch Y movement
					if (typeof touch.trackY == "undefined") {
						touch.trackY = [e.targetTouches[i].pageY];
					}
					else {
						touch.trackY.push(e.targetTouches[i].pageY);
					}

					touch.pageXLatest = e.targetTouches[i].pageX;
					touch.pageYLatest = e.targetTouches[i].pageY;
					touch.pageXDifference = touch.pageXLatest - touch.pageXStart;
					touch.pageYDifference = touch.pageYLatest - touch.pageYStart;
					touch.pageDifference = Math.abs(touch.pageXDifference) + Math.abs(touch.pageYDifference);
					touch.velocity = touch.pageDifference / duration;
				}

				switch (touches.length) {

					// TAP, DRAG, SWIPE
					case 1:

						// get the touch object
						touch = touches[0];

						// build history of touchpositions while dragging
						trackTouchPosition(touch);

						// define swipe velocity
						var swipeVelocity = 0.3;
						var maxSwipeDuration = 1000;

						// redefine if user maybe is trying to perform some action
						userActions.swiping = false;
						userActions.dragging = false;

						// SWIPE: user should move 1 finger fast
						if (Math.abs(touch.velocity) > swipeVelocity && duration < maxSwipeDuration) {
							userActions.swiping = true;
						}
						else {
							// DRAG: user should move 1 finger more then 10px
							if (touch.pageDifference > 20) {
								userActions.dragging = true;
								addTriggerToElement('drag', element, positionHistory);
							}
								// TAP
							else {
								userActions.tapping = true;
							}
						}
						break;

						// PINCHING
					case 2:

						// two fingers should move apart or to each other
						var touch1 = touches[0];
						var touch2 = touches[1];
						var currentPinchDistanceX = 0;
						var previousPinchDistanceX = 0;
						var currentPinchDistanceY = 0;
						var previousPinchDistanceY = 0;


						// calculate current distance between touches X
						touch1.currentX = touch1.trackX[touch1.trackX.length - 1];
						touch2.currentX = touch2.trackX[touch2.trackX.length - 1];
						if (touch1.currentX >= touch2.currentX) {
							currentPinchDistanceX = touch1.currentX - touch2.currentX;
						}
						else {
							currentPinchDistanceX = touch2.currentX - touch1.currentX;
						}


						// calculate current distance between touches Y
						touch1.currentY = touch1.trackY[touch1.trackY.length - 1];
						touch2.currentY = touch2.trackY[touch2.trackY.length - 1];
						if (touch1.currentY >= touch2.currentY) {
							currentPinchDistanceY = touch1.currentY - touch2.currentY;
						}
						else {
							currentPinchDistanceY = touch2.currentY - touch1.currentY;
						}


						// calculate previous distance X between touches
						touch1.previousX = touch2.previousX = 0;
						if (touch1.trackX.length > 2) {
							touch1.previousX = touch1.trackX[touch1.trackX.length - 2];
						}
						if (touch2.trackX.length > 2) {
							touch2.previousX = touch2.trackX[touch2.trackX.length - 2];
						}
						if (touch1.previousX >= touch2.previousX) {
							previousPinchDistanceX = touch1.previousX - touch2.previousX;
						}
						else {
							previousPinchDistanceX = touch2.previousX - touch1.previousX;
						}


						// calculate previous distance X between touches
						touch1.previousY = touch2.previousY = 0;
						if (touch1.trackY.length > 2) {
							touch1.previousY = touch1.trackY[touch1.trackY.length - 2];
						}
						if (touch2.trackY.length > 2) {
							touch2.previousY = touch2.trackY[touch2.trackY.length - 2];
						}
						if (touch1.previousY >= touch2.previousY) {
							previousPinchDistanceY = touch1.previousY - touch2.previousY;
						}
						else {
							previousPinchDistanceY = touch2.previousY - touch1.previousY;
						}


						// calculate velocity
						pinchVelocityX = previousPinchDistanceX - currentPinchDistanceX;
						pinchVelocityY = previousPinchDistanceY - currentPinchDistanceY;
						pinchVelocity = pinchVelocityY + pinchVelocityX;

						// call it a pinch if velocity greater then 3
						if (Math.abs(pinchVelocity) > 3) {
							userActions.pinching = true;
							addTriggerToElement('pinch', element, [touch1, touch2]);
							if (pinchVelocity > 0) {
								addTriggerToElement('pinchOut', element, [touch1, touch2]);
							}
							else {
								addTriggerToElement('pinchIn', element, [touch1, touch2]);
							}
						}

						break;
				}

				e.preventDefault();
				e.stopPropagation();

			}, false);

		}


		function trackTouchPosition(touch) {
			positionHistory.push(
				{
					x: touch.pageXLatest,
					y: touch.pageYLatest,
				}
			);
		}

		function trackTouchEnd(element) {
			DOMelement = element[0];
			DOMelement.addEventListener('touchend', function (e) {

				// set event end time
				var d = new Date();
				end = d.getTime();

				// calculate event duration
				calculateDuration();

				var touch = touches[0];

				// DEFINE USER ACTIONS
				if (userActions.swiping) {

					if (typeof element.touch.swipe == 'function') {
						element.touch.swipe(touch);
					}

					// check what direction the user swipes
					var xPositive = false;
					if (touch.pageXDifference >= 0) {
						xPositive = true;
					}

					var yPositive = false;
					if (touch.pageYDifference >= 0) {
						yPositive = true;
					}

					// define if we need to swipe right or bottom
					if (xPositive && yPositive) {
						if (touch.pageXDifference >= touch.pageYDifference) {
							addTriggerToElement('swipeRight', element, touch);
						}
						else {
							addTriggerToElement('swipeDown', element, touch);
						}
					}
						// define if we need to swipe left or top
					else if (!xPositive && !yPositive) {
						if (touch.pageXDifference <= touch.pageYDifference) {
							addTriggerToElement('swipeLeft', element, touch);
						}
						else {
							addTriggerToElement('swipeUp', element, touch);
						}
					}
						// define if we need to swipe right or top
					else if (xPositive && !yPositive) {
						if (touch.pageXDifference >= Math.abs(touch.pageYDifference)) {
							addTriggerToElement('swipeRight', element, touch);
						}
						else {
							addTriggerToElement('swipeUp', element, touch);
						}
					}
						// define if we need to swipe left or bottom
					else if (!xPositive && yPositive) {
						if (Math.abs(touch.pageXDifference) >= touch.pageYDifference) {
							addTriggerToElement('swipeLeft', element, touch);
						}
						else {
							addTriggerToElement('swipeDown', element, touch);
						}
					}
				}
				else if (userActions.tapping) {
					addTriggerToElement('tap', element, touch);
				}

				// gesture end
				addTriggerToElement('gestureEnd', element, touch);

				e.preventDefault();
				e.stopPropagation();

			}, false);
		}


		function trackTouchEnter(element) {
			DOMelement = element[0];
			DOMelement.addEventListener('touchenter', function (e) {
				log('enter');
			}, false);
		}


		function trackTouchLeave(element) {
			DOMelement = element[0];
			DOMelement.addEventListener('touchleave', function (e) {
				log('leave');
			}, false);
		}


		function trackTouchCancel(element) {
			DOMelement = element[0];
			DOMelement.addEventListener('touchcancel', function (e) {

				// set event end time
				var d = new Date();
				end = d.getTime();

				// calculate event duration
				calculateDuration();

				e.preventDefault();

			}, false);
		}


		function addTriggerToElement(trigger, element, touch) {
			if (typeof element.touch[trigger] == 'function') {
				element.touch[trigger](touch);
			}
		}


		function addGestureListener(events, callback) {
			var arr_events = events.replace(' ', '').split(",");
			for (var i in arr_events) {
				this.touch[arr_events[i]] = callback;
			}
		}


		return {
			track: track
		};
	}();
	
})(jQuery, cdb.lib = (cdb.lib === undefined) ? {} : cdb.lib);