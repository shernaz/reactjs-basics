/*
USAGE:
	var responsiveHandler = lib.ResponsiveHandler;
	responsiveHandler.init();

	responsiveHandler.subscribe('desktop', function (topic, data) {
		// do something
	});

*/

if(cdb === undefined) {
	var cdb = this;
}

(function($, lib) {
	'use strict';

	lib.PatternPublisherSubscriber = function() {

		var q = {},
 			topics = {},
			subUid = -1;

		q.publish = function (topic, args) {
			if (!topics[topic]) {
				return false;
			}
			var subscribers = topics[topic],
				len = subscribers ? subscribers.length : 0;

			while (len--) {
				subscribers[len].func(args);
			}
			return this;
		};

		q.subscribe = function (topic, func) {
			if (!topics[topic]) {
				topics[topic] = [];
			}
			var token = (++subUid).toString();
			topics[topic].push({
				token: token,
				func: func
			});
			return token;
		};

		q.unsubscribe = function (token) {
			for (var m in topics) {
				if (topics[m]) {
					for (var i = 0, j = topics[m].length; i < j; i++) {
						if (topics[m][i].token === token) {
							topics[m].splice(i, 1);
							return token;
						}
					}
				}
			}
			return this;
		};

		return q;
	}();

})(jQuery, cdb.lib = (cdb.lib === undefined) ? {} : cdb.lib);

(function($, lib, publisher_pattern) {
	'use strict';

	lib.ResponsiveHandler = function() {
		var classNamePrefix = 'breakpoint-';
		var $htmlElement = $('html');

		// get publisher subscriber pattern
		var publisher = publisher_pattern;

		var active_breakpoints = [];

		var breakpoints = null;

		function init() {
			/* get and handle breakpoints (sync mode) */
			$.ajaxSetup({ async: false });
			$.getJSON('/Assets/settings/breakpoints.json', function (data) {

				breakpoints = data;

				var responsive_handler = $('<div id="responsive-handler"></div>');

				for (var i in breakpoints) {
					breakpoints[i] = $('<div class="show-on-' + i + '"></div>');
					responsive_handler.append(breakpoints[i]);
					responsive_handler.css('display', 'absolute').css('top', '-10000px').css('left', '-10000px');
					$('body').prepend(responsive_handler);
				}

				$(window).resize(function () {
					checkActiveBreakPoints();
				});
			});
			$.ajaxSetup({ async: true });

			checkActiveBreakPoints();
		}

		/* adds breakpont class to html */
		function addBreakpointClasses() {
			for (var i in active_breakpoints) {
				var className = classNamePrefix + active_breakpoints[i];
				$htmlElement.addClass(className);
			}
		}

		// Removes all breakpoint classes from html element
		function clearBreakpointClasses() {
			for (var i in breakpoints) {
				var className = classNamePrefix + i;
				if ($htmlElement.hasClass(className)) {
					$htmlElement.removeClass(className);
				}
			}
		}


		function breakpointActive(breakpoints) {
			breakpoints = breakpoints.split(',');
			for (var i in breakpoints) {
				var breakpoint = breakpoints[i].trim();

				if ($htmlElement.hasClass(classNamePrefix + breakpoint)) {
					return true;
				}
			}
			return false;
		}


		function checkActiveBreakPoints() {

			// clear active breakpoints
			var previous_active_breakpoints = active_breakpoints;
			active_breakpoints = [];

			// remove breakpoint classes from html element
			clearBreakpointClasses();

			for (var i in breakpoints) {

				// check if break point is added to active breakpoints array
				var isRegistered = (active_breakpoints.indexOf(i) >= 0);
				var previouslyRegistered = (previous_active_breakpoints.indexOf(i) >= 0);

				// check if break point is visible
				var isVisible = $(breakpoints[i]).is(':visible');

				// add break point to active breakpoints array and publish content
				if (isVisible && !isRegistered) {
					active_breakpoints.push(i);
					if (!previouslyRegistered) {
						publisher.publish(i);
					}
				}

			}

			// add active breakpoint classes to html element
			addBreakpointClasses();
		}

		function republish() {
			for (var i in active_breakpoints) {
				publisher.publish(active_breakpoints[i]);
			}
		}

		function subscribe(breakpoints, callBack) {
			breakpoints = breakpoints.split(',');
			for (var i in breakpoints) {
				var breakpoint = breakpoints[i].trim();
				publisher.subscribe(breakpoint, callBack);
			}
		}

		function subscribe_to_all(callBack) {
			for (var topic in breakpoints) {
				publisher.subscribe(topic, callBack);
			}
		}

		function getActiveBreakpoints() {
			return active_breakpoints;
		}

		return {
			init: init,
			subscribe: subscribe,
			subscribe_to_all: subscribe_to_all,
			republish: republish,
			getActiveBreakpoints: getActiveBreakpoints,
			breakpointActive: breakpointActive
		};
	}();

})(jQuery, cdb.lib = (cdb.lib === undefined) ? {} : cdb.lib, cdb.lib.PatternPublisherSubscriber);