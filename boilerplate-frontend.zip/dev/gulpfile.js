/// <binding />
var outputStyle = "compressed";

var gulp = require("gulp"),
	styleguide = require("devbridge-styleguide"),
	runSequence = require("run-sequence"),
	_ = require("gulp-load-plugins")();

var buildFolder = "../";
var publicFolder = "../public";

gulp.task("pug",
	function(cb) {
		gulp.src([
				"html/*.pug"
			])
			.pipe(_.pug({
				pretty: true,
				locals: {
					production: true
				}
			}))
			.pipe(gulp.dest(publicFolder))
			.pipe(_.debug());

		gulp.src([
				"html/**/*.pug",
				"!html/layouts/partials/*.pug"
			])
			.pipe(_.pug({
				production: false,
				pretty: true,
				locals: {
					production: false
				}
			}))
			.pipe(gulp.dest(buildFolder + "/dist"))
			.pipe(_.debug());

		cb();
	});

gulp.task("sass",
	function() {
		return gulp.src("assets/sass/*.scss")
			.pipe(_.sourcemaps.init())
			.pipe(_.sass({ outputStyle: "expanded" }).on("error", _.sass.logError))
			.pipe(_.autoprefixer({
				browsers: ["last 4 versions"],
				cascade: false
			}))
			.pipe(_.sourcemaps.write())
			.pipe(gulp.dest("assets/css"))
			.pipe(_.livereload())
			.pipe(_.debug());
	});

gulp.task("cssBuild",
	function() {
		var productionOptions = {
			keepSpecialComments: 0
		};

		return gulp.src([
				"assets/css/*.css",
				"!assets/css/*-min.css"
			])
			.pipe(gulp.dest(publicFolder + "/assets/css"))
			.pipe(_.debug())
			.pipe(gulp.dest(buildFolder + "/assets/css"))
			.pipe(_.debug())
			.pipe(_.rename({ suffix: "-min" }))
			.pipe(_.cleanCss(productionOptions))
			.pipe(gulp.dest(buildFolder + "/assets/css"))
			.pipe(_.debug());
	});

gulp.task("styleguide",
	function() {
		//styleguide.startServer();
	});

gulp.task("assets:copy",
	function() {
		return gulp.src([
				"assets/**",
				"!assets/{sass,sass/**}",
				"!assets/{css,css/**}"
			])
			.pipe(gulp.dest(buildFolder + "/assets"))
			.pipe(gulp.dest(publicFolder + "/assets"));
	});

gulp.task("img:copy",
	function() {
		return gulp.src("images/**/*")
			.pipe(gulp.dest(buildFolder + "/images"))
			.pipe(gulp.dest(publicFolder + "/images"));
	});

gulp.task("js:minify",
	function() {
		return gulp.src(["assets/js/**/*.js", "!assets/js/**/*-min.js"])
			.pipe(_.rename({ suffix: "-min" }))
			.pipe(_.uglify())
			.pipe(gulp.dest(buildFolder + "/assets/js"))
			.pipe(gulp.dest(publicFolder + "/assets/js"))
			.pipe(_.debug());
	});

gulp.task("js:lint",
	function() {
		return gulp.src([
				"assets/js/**/*.js",
				"!assets/js/{vendor,vendor/**}"
			])
			.pipe(_.jshint())
			.pipe(_.jshint.reporter(_.stylish));
	});

gulp.task("sass:watch",
	function() {
		gulp.watch("assets/sass/**/*.scss", ["sass"]);
	});

gulp.task("watch",
	["sass", "sass:watch", "styleguide"],
	function() {
		_.livereload.listen();
	});

gulp.task("clean",
	function(cb) {
		return gulp.src([
				buildFolder+"/assets",
				buildFolder+"/images",
				buildFolder+"/dist",
				publicFolder
			])
			.pipe(_.rimraf({ force: true }));
	});

gulp.task("build",
	function(cb) {
		runSequence(
			"clean",
			[
				"pug",
				"sass",
				"js:minify",
				"img:copy"
			],
			"cssBuild",
			"assets:copy",
			cb);
	});

gulp.task("cleanPublish",
function(cb) {
	return gulp.src([
 				"" //harddisk destination
 			])
 			.pipe(_.rimraf({ force: true }));
});

gulp.task("publish",
	function() {
		return gulp.src([
		 		publicFolder + "/**"
		])
		.pipe(gulp.dest("")); // harddisk destination
	});